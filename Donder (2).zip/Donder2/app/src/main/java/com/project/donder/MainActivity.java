package com.project.donder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;
import com.project.donder.Cards.arrayAdapter;
import com.project.donder.Cards.cards;
import com.project.donder.Matches.MatchesActivity;
import com.yuyakaido.android.cardstackview.CardStackLayoutManager;
import com.yuyakaido.android.cardstackview.CardStackListener;
import com.yuyakaido.android.cardstackview.CardStackView;
import com.yuyakaido.android.cardstackview.Direction;
import com.yuyakaido.android.cardstackview.StackFrom;
import com.yuyakaido.android.cardstackview.SwipeableMethod;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

   /*private cards cards_data[];
    private com.project.donder.Cards.arrayAdapter arrayAdapter;
    private int i;

    private FirebaseAuth mAuth;
    private String currentUId;

    private DatabaseReference usersDb;

    ListView listView;
    List<cards> rowItems;*/

    private static final String TAG = "MainActivity";
    private CardStackLayoutManager manager;
    private CardStackAdapter adapter;

   /* @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usersDb = FirebaseDatabase.getInstance().getReference().child("Users");

        mAuth = FirebaseAuth.getInstance();
        currentUId = mAuth.getCurrentUser().getUid();

        //checkUserSex();

        rowItems = new ArrayList<cards>();

        arrayAdapter = new arrayAdapter(this, R.layout.item, rowItems);


        SwipeFlingAdapterView flingContainer = findViewById(R.id.frame);*/

       //flingContainer.setAdapter(arrayAdapter);
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            CardStackView cardStackView = findViewById(R.id.card_stack_view);
            manager = new CardStackLayoutManager(this, new CardStackListener() {
                @Override
                public void onCardDragging(Direction direction, float ratio) {
                    Log.d(TAG, "onCardDragging: d=" + direction.name() + " ratio=" + ratio);
                }

                @Override
                public void onCardSwiped(Direction direction) {
                    Log.d(TAG, "onCardSwiped: p=" + manager.getTopPosition() + " d=" + direction);
                    if (direction == Direction.Right){
                        Toast.makeText(MainActivity.this, "Direction Right", Toast.LENGTH_SHORT).show();
                    }
                    if (direction == Direction.Top){
                        Toast.makeText(MainActivity.this, "Direction Top", Toast.LENGTH_SHORT).show();
                    }
                    if (direction == Direction.Left){
                        Toast.makeText(MainActivity.this, "Direction Left", Toast.LENGTH_SHORT).show();
                    }
                    if (direction == Direction.Bottom){
                        Toast.makeText(MainActivity.this, "Direction Bottom", Toast.LENGTH_SHORT).show();
                    }

                    // Paginating
                    if (manager.getTopPosition() == adapter.getItemCount() - 5){
                        paginate();
                    }

                }

                @Override
                public void onCardRewound() {
                    Log.d(TAG, "onCardRewound: " + manager.getTopPosition());
                }

                @Override
                public void onCardCanceled() {
                    Log.d(TAG, "onCardRewound: " + manager.getTopPosition());
                }

                @Override
                public void onCardAppeared(View view, int position) {
                    TextView tv = view.findViewById(R.id.item_name);
                    Log.d(TAG, "onCardAppeared: " + position + ", nama: " + tv.getText());
                }

                @Override
                public void onCardDisappeared(View view, int position) {
                    TextView tv = view.findViewById(R.id.item_name);
                    Log.d(TAG, "onCardAppeared: " + position + ", nama: " + tv.getText());
                }
            });
            manager.setStackFrom(StackFrom.None);
            manager.setVisibleCount(3);
            manager.setTranslationInterval(8.0f);
            manager.setScaleInterval(0.95f);
            manager.setSwipeThreshold(0.3f);
            manager.setMaxDegree(20.0f);
            manager.setDirections(Direction.FREEDOM);
            manager.setCanScrollHorizontal(true);
            manager.setSwipeableMethod(SwipeableMethod.Manual);
            manager.setOverlayInterpolator(new LinearInterpolator());
            adapter = new CardStackAdapter(addList());
            cardStackView.setLayoutManager(manager);
            cardStackView.setAdapter(adapter);
            cardStackView.setItemAnimator(new DefaultItemAnimator());

        }

        private void paginate() {
            List<ItemModel> old = adapter.getItems();
            List<ItemModel> baru = new ArrayList<>(addList());
            CardStackCallback callback = new CardStackCallback(old, baru);
            DiffUtil.DiffResult hasil = DiffUtil.calculateDiff(callback);
            adapter.setItems(baru);
            hasil.dispatchUpdatesTo(adapter);
        }

        private List<ItemModel> addList() {
            List<ItemModel> items = new ArrayList<>();
            items.add(new ItemModel(R.drawable.sample1, "Markonah", "24", "Jember"));
            items.add(new ItemModel(R.drawable.sample2, "Marpuah", "20", "Malang"));
            items.add(new ItemModel(R.drawable.sample3, "Sukijah", "27", "Jonggol"));
            items.add(new ItemModel(R.drawable.sample4, "Markobar", "19", "Bandung"));
            items.add(new ItemModel(R.drawable.sample5, "Marmut", "25", "Hutan"));

            items.add(new ItemModel(R.drawable.sample1, "Markonah", "24", "Jember"));
            items.add(new ItemModel(R.drawable.sample2, "Marpuah", "20", "Malang"));
            items.add(new ItemModel(R.drawable.sample3, "Sukijah", "27", "Jonggol"));
            items.add(new ItemModel(R.drawable.sample4, "Markobar", "19", "Bandung"));
            items.add(new ItemModel(R.drawable.sample5, "Marmut", "25", "Hutan"));
            return items;
        }
    }


// flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
           /* public void removeFirstObjectInAdapter() {
                // this is the simplest way to delete an object from the Adapter (/AdapterView)
                Log.d("LIST", "removed object!");
                rowItems.remove(0);
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object dataObject) {

                cards obj = (cards) dataObject;
                String userId = obj.getUserId();
                usersDb.child(userId).child("connections").child("nope").child(currentUId).setValue(true);
                Toast.makeText(MainActivity.this, "left", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRightCardExit(Object dataObject) {

                cards obj = (cards) dataObject;
                String userId = obj.getUserId();
                usersDb.child(userId).child("connections").child("yep").child(currentUId).setValue(true);
                isConnectionMatch(userId);
                Toast.makeText(MainActivity.this, "right", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdapterAboutToEmpty(int itemsInAdapter) {
            }
            @Override
            public void onScroll(float scrollProgressPercent) {
            }
        });


        // Optionally add an OnItemClickListener
        flingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int itemPosition, Object dataObject) {
                Toast.makeText(MainActivity.this, "click", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void isConnectionMatch(String userId) {
        DatabaseReference currentUserConnectionsDb  = usersDb.child(currentUId).child("connections").child("yep").child(userId);
        currentUserConnectionsDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
              if(dataSnapshot.exists()){
                  Toast.makeText(MainActivity.this, "new Connection", Toast.LENGTH_LONG).show();

                  String key = FirebaseDatabase.getInstance().getReference().child("Chat").push().getKey();

                  usersDb.child(dataSnapshot.getKey()).child("connections").child("matches").child(currentUId).child("ChatId").setValue(key);
                  usersDb.child(currentUId).child("connections").child("matches").child(dataSnapshot.getKey()).child("ChatId").setValue(key);

              }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private String userSex;
    private String oppositeUserSex;

      public void checkUserSex(){
          final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
          DatabaseReference userDb = usersDb.child(user.getUid());
          userDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    if (dataSnapshot.child("sex").getValue() != null) {
                        userSex = dataSnapshot.child("sex").getValue().toString();
                        switch (userSex) {
                            case "Male":
                                oppositeUserSex = "Female";
                                break;
                            case "Female":
                                oppositeUserSex = "Male";
                                break;
                        }
                        getOppositeSexUsers();
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
      }

      public void getOppositeSexUsers(){
        usersDb.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
               if(dataSnapshot.exists() && !dataSnapshot.child("connections").child("nope").hasChild(currentUId) && !dataSnapshot.child("connections").child("yep").hasChild(currentUId) && dataSnapshot.child("sex").getValue().toString().equals(oppositeUserSex)){
                  String profileImageUrl = "default" ;
                  if (!dataSnapshot.child("profileImageUrl").getValue().equals("default"));{
                       profileImageUrl = dataSnapshot.child("profileImageUrl").getValue().toString();
                   }
                   cards item = new cards(dataSnapshot.getKey(), dataSnapshot.child("name").getValue().toString(), profileImageUrl);
                    rowItems.add(item);
                    arrayAdapter.notifyDataSetChanged();
               }
            }
            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            }
            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void logoutUser(View view) {
        mAuth.signOut();
        Intent intent = new Intent(MainActivity.this, ChooseLoginRegistrationActivity.class);
        startActivity(intent);
        finish();
        return;
    }

    public void goToSettings(View view) {
        Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
        startActivity(intent);
        return;
    }

    public void goToMatches(View view) {
          Intent intent = new Intent(MainActivity.this, MatchesActivity.class);
        startActivity(intent);
        return;
    }*/
